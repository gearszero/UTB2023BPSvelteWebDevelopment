import "$lib/supabaseClient.js";
import { getSupabase } from '@supabase/auth-helpers-sveltekit';

export const handle = async ({ event, resolve }) => {
	const { supabaseClient } = await getSupabase(event);

	event.locals.sb = supabaseClient;
	event.locals.session = async () => {
		const {
			data: {session},
		} = await event.locals.sb.auth.getSession();
		return session;
	};

	return resolve(event)
}