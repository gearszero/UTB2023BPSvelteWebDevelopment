import { writable } from 'svelte/store';
import { browser } from '$app/environment';

const data = browser ? JSON.parse(window.localStorage.getItem('usr-cart')) ?? [] : [];

export const usersCartStore = writable(data);

usersCartStore.subscribe((value) => {
	if (browser) {
		localStorage.setItem('usr-cart', JSON.stringify(value));
	}
});

export const addToCart = (data) => {
	usersCartStore.update((currentItems) => {
		return [...currentItems, data];
	})
}

export const deleteFromCart = (id) => {
	usersCartStore.update((currentItems) => {
		return currentItems.filter(item => item.cart_id !== id);
	})
}

export const getCartItems = () => {
	let cartItems;
	usersCartStore.subscribe(value => {
		cartItems = value;
	});
	return cartItems;
}

//Change the items quantity by id that is passed and amout that is passed, also change the total price
export const changeQuantity = (id, amount) => {
	usersCartStore.update((currentItems) => {
		return currentItems.map(item => {
			if (item.cartOrderId === id) {
				item.quantity = amount;
			}
			return item;
		})
	})
}

// create a function that will return the total length of the cart
export const getCartLength = () => {
	let cartLength;
	usersCartStore.subscribe(value => {
		cartLength = value.length;
	});
	return cartLength;
}

// clear local storage
export const clearCart = () => {
	usersCartStore.set([]);
	localStorage.clear();
}
