<script>
	import { onMount } from 'svelte';
	import { usersCartStore } from '../store/usersCartStore';

	//export
	export let session;
	//variables
	let isScrolled = false;
	let screenWidth = 0;
	let toggled = 'closed';


	onMount(() => {
		screenWidth = screen.width;
		window.addEventListener('scroll', handleScroll);
		return () => {
			window.removeEventListener('scroll', handleScroll);
		};
	});

	function handleScroll() {
		isScrolled = window.scrollY > 80;
	}

	function handleDisplay() {
		if (isScrolled) {
			return 'none';
		} else {
			console.log('block');
			return 'block';
		}
	}

	function openMenu() {
		if (toggled === 'open')
			toggled = 'closed';
		else
			toggled = 'open';
	}
</script>

	<nav class='w-full z-20' class:scrolled={isScrolled} style='display: {handleDisplay()}'>
		<div class='hidden lg:grid grid-cols-12 my-5 mx-12 gap-5'>
			<a href='/'>
				<img src='src/tmpPics/LogoWithoutDwhite.svg' width='64' height='32' alt='small logo'>
			</a>
			<a href='/hoodies' class='align-items text'> MIKINY </a>
			<div class='align-items'>TRIČKA</div>
			<div class='align-items col-span-2'>SHOP ALL</div>

			{#if session === null}
				<a href='/login' class='col-start-11 text-lg self-center'>LOGIN</a>
			{:else }
				<div class='col-start-10 text-base self-center dropdown dropdown-bottom pl-2'>
					<button tabindex='0' class='btn-invisible select-text flex flex-row items-center'>
						<i class='bi bi-person mr-2 text-xl'></i>
						{session.user.email}
						<i class='bi bi-chevron-down ml-2'></i>
					</button>
					<ul tabindex='0' class='dropdown-content menu p-2 background-dropdown w-52'>
						<li class='bottom-border-dropdown'>
							<form action='/logout' method='POST'>
								<button class='logout-button'>LOGOUT</button>
							</form>
						</li>
					</ul>
				</div>
			{/if}

			<div class='col-start-12 text-3xl text-right self-center'>
				<a href='/cart'>
					{#if $usersCartStore.length > 0}
						<div class='notify-cart'> {$usersCartStore.length} </div>
					{/if}
					<i class='bi bi-bag'></i>
				</a>
			</div>

		</div>
	</nav>

	<nav class='w-full z-20 background-color block lg:hidden'>
		<div class='grid grid grid-cols-10'>
			<a href='/'>
				<img class='py-3 ml-4' src='src/tmpPics/LogoWithoutDwhite.svg' width='48' height='24' alt='small logo'>
			</a>

			<a href='/cart' class='col-start-9 mt-4'>
				{#if $usersCartStore.length > 0}
					<div class='text-xs sm:text-sm absolute align-middle mt-[0.52rem] ml-[0.4rem] sm:mt-[0.7rem] sm:ml-[0.65rem]'> {$usersCartStore.length} </div>
				{/if}
				<i class='bi bi-bag text-xl sm:text-3xl'></i>
			</a>

			<div class='col-start-10 align-middle'>
				<button class='menu-open-button mr-4 mt-4' on:click={openMenu}>
					<i class='bi bi-list text-2xl sm:text-4xl'></i>
				</button>

				<div class="menu-close {toggled === 'open' ? 'block' : 'hidden'}">
					<div class='menu-list'>
						<button class='menu-close-button' on:click={openMenu}>
							<i class='bi bi-x-lg text-2xl'></i>
						</button>
						<a href='/hoodies' class='mt-24 flex justify-center' on:click={openMenu}> MIKINY </a>
						<div class='flex justify-center' on:click={openMenu}>TRIČKA</div>
						<div class='flex justify-center' on:click={openMenu}>SHOP ALL</div>
						<div class='flex justify-center mt-8'>
							{#if session === null}
								<a href='/login' class='col-start-11 text-lg self-center' on:click={openMenu}>LOGIN</a>
							{:else }
								<div class='flex flex-col'>
									<div>
										<i class='bi bi-person mr-2 text-xl'></i>
										{session.user.email}
									</div>
									<div class='flex justify-center mt-4'>
										<form action='/logout' method='POST'>
											<button>LOGOUT</button>
										</form>
									</div>
								</div>
							{/if}
						</div>
					</div>
				</div>
			</div>

		</div>
	</nav>


<style>

    .menu-list {
        @apply flex flex-col gap-5 h-80 w-full fixed right-0;
        background-color: var(--theme-color);
    }

    .menu-close {
        @apply fixed top-0;
    }

    .menu-close-button {
        @apply fixed top-4 right-7;
        background-color: var(--theme-color);
    }

    .logout-button {
        @apply w-full h-10 text-lg font-medium align-middle;
        color: var(--text-color);
        border: 1px solid var(--text-color);
    }

    .bi-bag {
        color: var(--text-color);
    }

    .background-color {
        background-color: var(--theme-color);
    }

    nav {
        top: 0;
        position: fixed;
        background-color: transparent;
        transition: background-color 0.5s ease-in-out;
    }

    nav.scrolled {
        position: fixed;
        top: 0;
        width: 100%;
        display: none;
        background-color: var(--theme-color);
        transition: background-color 0.5s ease-in-out;
    }

    hr {
        color: var(--text-color);
    }

    .align-items {
        @apply text-xl inline-block font-bold flex self-center ;
    }

		.notify-cart {
			@apply absolute top-9 right-10 w-4 h-4 rounded-full text-white text-xs flex items-center justify-center;
			background-color: #e81a1a;
		}

		.notify-cart-mobile{
			@apply absolute top-0 right-40 w-4 h-4 rounded-full text-white text-xs flex items-center justify-center;
			background-color: #e81a1a;
		}

</style>
