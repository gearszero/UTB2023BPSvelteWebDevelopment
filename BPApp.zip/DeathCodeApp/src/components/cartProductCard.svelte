<script>
    import {deleteFromCart, changeQuantity} from '../store/usersCartStore.js';
    import {onMount} from "svelte";

    //xports
    export let product;
    export let maximumQuantity;
    export let isLocal;

    // Variables
    let toggleQtyDropDown = false;

    onMount(() => {
        if (product.quantity > maximumQuantity) {
            changeProductQuantity(product.cart_id, maximumQuantity)
        }

        console.log(maximumQuantity)
        console.log(product)
    })

    //functions
    function changeProductQuantity(orderId, quantity) {
        product.quantity = quantity;
        changeQuantity(orderId, quantity)
    }

    function toggleQuantityDropDown() {
        console.log(toggleQtyDropDown);
        toggleQtyDropDown = !toggleQtyDropDown;
    }


</script>

<div>
    <div class='cart-product-border w-[50rem]'>
        <div class='flex flex-row my-8 mx-14 '>
            <a href='../{product.product_id}t={product.product_type}'>
                <div class='flex justify-start'>
                    <img class='w-64 h-auto' src={product.product_image}
                         alt={product.product_name}/>
                </div>
            </a>
            <div class='flex flex-col justify-start ml-4 w-96'>
                <div class='text-2xl font-extrabold'>
                    <span>{product.product_name}</span>
                </div>
                <div class='text-xl font-extrabold ml-4 mt-4'>
                    <div class='my-2'>
                        <span>VELIKOST : {product.product_size}</span>
                    </div>
                    <div class='my-2'>
                        <span>STYLE : {product.product_version}</span>
                    </div>
                    <div class='my-2'>
                        <span>Q-TY : </span>
                        <div class="dropdown">
                            <label tabindex="0" class="cursor-pointer"
                                   on:click={toggleQuantityDropDown}>{product.quantity} <i
                                    class='bi bi-chevron-down'></i></label>
                            <ul tabindex="0"
                                class="dropdown-content menu background-theme-color text-sm flex items-center {toggleQtyDropDown === false ? 'hidden' : 'block'}">
                                {#each Array.from({length: maximumQuantity}, (_, i) => i + 1) as number}
                                    <li>
                                        <div on:click={() => {changeProductQuantity(product.cart_id, number); toggleQuantityDropDown()}}>{number}</div>
                                    </li>
                                {/each}
                            </ul>
                        </div>
                    </div>
                    {#if isLocal}
                        <div class='justify-end my-14'>
                            <span>CENA : {product.product_price * product.quantity} CZK</span>
                        </div>
                    {:else}
                        <div class='justify-end my-14'>
                            <span>CENA : {product.total_price} CZK</span>
                        </div>
                    {/if}
                </div>
            </div>
            <div class='cursor-pointer ml-5' on:click={() => {deleteFromCart(product.cart_id); location.reload()}}>
                <i class='bi bi-x-lg text-2xl'></i>
            </div>
        </div>
    </div>
</div>

<style>
    .cart-product-border {
        border-top: 1px solid var(--text-color);
        border-bottom: 1px solid var(--text-color);
    }

    .bi-x-lg:hover {
        color: var(--white-hover-color);
    }
</style>