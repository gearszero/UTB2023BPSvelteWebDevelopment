<script>
	import { beforeUpdate } from 'svelte/internal';

	//components

	// local variables
	let spaceSize = 20;
	let size = 0;
	let wordSize = 0;
	let iterator = 0;

	let isFullColor = false;
	let isSwitched = false;

	// enum Color { White = 0, Purple = 1, PurpleSwitched = 2, WhiteSwitched = 3, Nothing = 4}
	let colorText = [];

	beforeUpdate(() => {
		size = screen.width
		if (size > 1024) {
			wordSize = 330;
		}
		else {
			wordSize = size / 4;
		}
		iterator = Math.floor(size / (wordSize + spaceSize * 2)) - 1;

		for (iterator; iterator >= 0; iterator--) {
			colorText.push(setColor(iterator));
		}
	})

	function setColor(position) {
		if ((position % 2 === 0 && isFullColor && position !== 0)) {
			isFullColor = !isFullColor;
			return 1;
		} else if ((position % 3 === 0 && !isSwitched && position !== 0) || position === 7) {
			isSwitched = !isSwitched;
			return 2;
		} else if ((position % 3 === 0 && isSwitched && position !== 0) || position === 1 || position === 5) {
			isSwitched = !isSwitched;
			return 3;
		} else if (position % 2 === 0) {
			isFullColor = !isFullColor;
			return 0;
		}
		return 4;
	}
</script>

<div>
	<div class="border-separator">
		<div class="flex justify-center align-middle py-2">
			{#each colorText as colorSet}
				{#if colorSet === 0}
					<span class="text-base md:text-3xl lg:text-4xl font-extrabold px-5">DEATHCODE</span>
				{:else if colorSet === 1}
					<span class="text-base lg:text-4xl md:text-3xl font-extrabold text-color-purple px-5">DEATHCODE</span>
				{:else if colorSet === 2}
					<span class="text-base lg:text-4xl md:text-3xl font-extrabold text-color-purple pl-5">DEATH</span>
					<span class="text-base lg:text-4xl md:text-3xl font-extrabold pr-5">CODE</span>
				{:else if colorSet === 3}
					<span class="text-base lg:text-4xl md:text-3xl font-extrabold pl-5">DEATH</span>
					<span class="text-base lg:text-4xl md:text-3xl font-extrabold text-color-purple pr-5">CODE</span>
				{/if}
			{/each}
		</div>
	</div>
</div>

<style>
	.border-separator {
		border-top: 2px solid var(--text-color);
		border-bottom: 2px solid var(--text-color);
		border-left: none;
		border-right: none;
		width: 100%;
	}

	.text-color-purple {
		color: #8808b5;
	}
</style>
