<script>

	// Passed values
	export let product;

	// functions

</script>

<div class='card-body sm:pb-16'>
	{#if product.isBestSeller}
		<div
				class='absolute pl-1 md:pl-3 text-xs sm:text-sm lg:text-lg xl:text-xl font-semibold w-1/2 best-seller-text-border left-4'>
			BESTSELLER
		</div>
	{/if}
	<div class='flex justify-center pt-4 items-center'>
		<img class='w-full h-full' src={product.product_image} alt={product.product_name} />
	</div>
	<div class='flex flex-col py-5 h-24 lg:h-32'>
		<div class='flex text-xs sm:text-lg md:text-xl lg:text-2xl font-normal justify-center'>{product.product_name}</div>
		{#if product.is_on_sale}
			<div class='flex text-xs sm:text-lg md:text-xl lg:text-2xl justify-center'>
				<span class='text-color-purple'> SALE {product.sale_ratio} %</span>
			</div>
			<span class='flex text-[0.65rem] sm:text-base md:text-lg justify-center font-extralight line-through text-zinc-600'>{product.product_price} CZK</span>
			<span class='flex text-xs sm:text-lg md:text-xl justify-center font-extralight'>{product.sale_price} CZK</span>
		{:else }
		<span class='flex text-xs sm:text-lg md:text-xl justify-center font-extralight'>{product.product_price} CZK</span>
		{/if}
	</div>
</div>

<style>
    .card-body {
        @apply flex;
        position: relative;
        border: 2px solid var(--text-color);
		border-left: 1px solid var(--text-color);
		border-right: 1px solid var(--text-color);
        background-color: transparent;
    }

    .best-seller-text-border {
        color: #f0f0f0;
        border: 2px solid #c213ff;
        border-radius: 1rem;
        background: -moz-linear-gradient(
                90deg,
                rgba(136, 8, 181, 1) 0%,
                rgba(189, 16, 183, 1) 59%,
                rgba(15, 15, 15, 1) 93%
        );
        background: -webkit-linear-gradient(
                90deg,
                rgba(136, 8, 181, 1) 0%,
                rgba(189, 16, 183, 1) 59%,
                rgba(15, 15, 15, 1) 93%
        );
        background: linear-gradient(
                90deg,
                rgba(136, 8, 181, 1) 0%,
                rgba(189, 16, 183, 1) 59%,
                rgba(15, 15, 15, 1) 93%
        );
    }
</style>
