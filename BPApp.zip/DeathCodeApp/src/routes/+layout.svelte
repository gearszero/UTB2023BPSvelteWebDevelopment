<script lang="ts">
	import '../app.css';
	import 'bootstrap-icons/font/bootstrap-icons.css';
	import Navbar from '../components/navbar.svelte';
	import { supabaseClient } from '$lib/supabaseClient';
	import { SvelteToast } from '@zerodevx/svelte-toast';
	import { onMount } from 'svelte';
	import { invalidateAll } from '$app/navigation';

	//TODO: Make Footer
	export let data;

	onMount(() => {
		const { data: { subscription }} = supabaseClient.auth.onAuthStateChange(() => {
			invalidateAll();
		});

		return () => {
			subscription.unsubscribe();
		}
	})

</script>
<Navbar session={data.session}/>
<SvelteToast />
<slot></slot>

<div class='footer'>
	<div class='flex w-1/3'>

	</div>
</div>

<style>
	.footer {
			@apply flex w-full h-1/5;
			background-color: var(--footer-color);
	}
</style>