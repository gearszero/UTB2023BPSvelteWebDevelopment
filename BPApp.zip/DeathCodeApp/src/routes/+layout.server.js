// on load we will get locals

export const load = async ({locals : {session}}) => {
	return {
		// Pokud user nebude validni neboli prihlasen tak vraci null jinak vraci usera
		session: await session()
	}
};
