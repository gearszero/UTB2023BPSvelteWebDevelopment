<script>

	// tahame z layout.server.ts a zjistujeme jestli je user loged in nebo ne
	export let data
</script>

<div class='main'>
	<form action='?/signup' method='POST' class='flex flex-col items-center justify-center w-3/4'>
		<div class='font-extrabold text-4xl mb-10'>SIGN UP</div>
		<div class='flex flex-col lg:flex-row items-center justify-center w-full'>
			<div class='flex flex-col flex-nowrap'>
				<div class='item-field'>
					<p>First Name *</p>
					<input type='text' name='firstName' class='input-field'>
				</div>
				<div class='item-field'>
					<p>Last Name *</p>
					<input type='text' name='lastName' class='input-field'>
				</div>
				<div class='item-field'>
					<p>Gender</p>
					<input type='text' name='gender' class='input-field'>
				</div>
			</div>
			<div class='flex flex-col lg:ml-44 flex-nowrap'>
				<div class='item-field'>
					<p>Email *</p>
					<input type='email' name='email' class='input-field'>
				</div>
				<div class='item-field'>
					<p>Password *</p>
					<input type='password' name='password' class='input-field'>
				</div>
				<div class='item-field'>
					<p>Confirm Password *</p>
					<input type='password' name='passwordConfirm' class='input-field'>
				</div>
			</div>
		</div>
		<button class='big-form-button'>
			SIGN UP
		</button>
	</form>
</div>

<style>
    .main {
        @apply flex justify-center items-center mt-32;
    }

		.item-field {
				@apply mb-10;
		}

    .input-field {
        @apply w-full h-8 pl-5 text-xl font-semibold my-5;
        background-color: var(--theme-color);
        border-bottom: 2px solid var(--text-color);
    }
</style>