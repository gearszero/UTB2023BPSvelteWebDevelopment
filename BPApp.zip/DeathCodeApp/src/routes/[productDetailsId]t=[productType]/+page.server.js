import { supabaseClient } from '$lib/supabaseClient.js';
import { fail } from '@sveltejs/kit';
import { setSaleRatio } from "$lib/utils.js";

export const load = async ({ params }) => {
	let selectedId  = params.productDetailsId
	let databaseTableName = params.productType

	const { data, error: err } = await supabaseClient.from(databaseTableName).select().eq('product_id', selectedId)

	if (err) {
		return fail(500, {
			error: 'Server error: Please try again later'
		})
	}

	if (data[0].is_on_sale) {
		data[0].sale_price = setSaleRatio(data[0].product_price, data[0].sale_ratio)
	}

	return {
		productData: data[0]
	}
}


