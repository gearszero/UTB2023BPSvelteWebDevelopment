<script>
    import {onMount} from 'svelte';
    import {addToCart, usersCartStore} from '../../store/usersCartStore.js';
    import {toast} from '@zerodevx/svelte-toast';
    import {uuid} from '@supabase/supabase-js/dist/module/lib/helpers';
    import {POST} from '../api/cart/+server.js';

    //TODO: More and browsable photos
    //TODO: See other products

    //export
    export let data;

    // data
    let productDetails = {};
    let versions = ['SPIKED', 'CLEAN'];
    let selectedVersion = 'VYBERTE VERZI';

    let availableSizes = [];
    let selectedSize = 'VYBERTE VELIKOST';
    let toggleSizeDropDown = false;
    let toggleVersionDropDown = false;
    let addedToCart = false;

    onMount(() => {
        productDetails = data.productData;
        getAvailableSizes(productDetails.sizes);
    });

    // functions
    function changeSelectedVersion(version) {
        selectedVersion = versions[version];
    }

    function changeSelectedSize(size) {
        selectedSize = size;
    }

    function closeDropDownSize() {
        toggleSizeDropDown = !toggleSizeDropDown;
    }

    function closeDropDownVersion() {
        toggleVersionDropDown = !toggleVersionDropDown;
    }

    function getAvailableSizes(sizes) {
        sizes.forEach(size => {
            if (size.available > 0) {
                availableSizes = [...availableSizes, size.sizeName];
            }
        });
        if (availableSizes.length === 0)
            selectedSize = 'Není dostupná žádná velikost';
    }

    /**
     * @brief: Add product to cart
     */
    function addItemToCart() {
        if (selectedSize === 'VYBERTE VELIKOST' || selectedVersion === 'VYBERTE VERZI') {
            if (selectedVersion === 'VYBERTE VERZI') {
                toast.push('Musíte vybrat verzi produktu', {
                    theme: {
                        '--toastBackground': '#a60000',
                        '--toastBarHeight': 0
                    }
                });
            }

            if (selectedSize === 'VYBERTE VELIKOST') {
                toast.push('Musíte vybrat velikost produktu', {
                    theme: {
                        '--toastBackground': '#a60000',
                        '--toastBarHeight': 0
                    }
                });
            }
            addedToCart = false;
            return false;
        }
        if (data.session){
            let addingItem = {
                product_id: productDetails.product_id,
                quantity: 1,
                product_size: selectedSize,
                product_version: selectedVersion,
                product_type: productDetails.product_type,
                product_name: productDetails.product_name,
                product_image: productDetails.product_image,
            }
            POST({params: addingItem})
            return true;
        }

        let addingItem = {
            cart_id: uuid(),
            product_id: productDetails.product_id,
            product_name: productDetails.product_name,
            product_price: productDetails.product_price,
            product_image: productDetails.product_image,
            product_size: selectedSize,
            quantity: 1,
            product_version: selectedVersion,
            product_type: productDetails.product_type
        };

        let isAdded = false;
        $usersCartStore.forEach(item => {
            if (item.productId === addingItem.productId && item.size === addingItem.size && item.version === addingItem.version) {
                item.quantity++;
                isAdded = true;
            }
        });

        if (!isAdded) {
            addToCart(addingItem);
        }
        addedToCart = true;

        return true;

    }
</script>

<div class='flex justify-center mt-32'>
    <div class='flex flex-col items-center xl:flex-row xl:items-start justify-center'>
        <div class='mb-20 xl:mb-0 flex flex-nowrap'>
            <div class='left-decor-border flex mr-4 hidden lg:block'></div>
            <img class='w-full md:w-auto product-image h-auto' src={productDetails.product_image}
                 alt={productDetails.product_name}/>
        </div>
        <div class='flex flex-col mx-7 max-w-[45rem]'>
            <div class='text-xl sm:text-3xl md:text-5xl lg:text-6xl font-extrabold'> {productDetails.product_name} </div>
            <hr class='hr-separator-smaller my-6'>
            {#if productDetails.is_on_sale}
                <div class='flex flex-col mb-3'>
                    <span class="text-lg md:text-xl lg:text-2xl font-extrabold line-through text-zinc-600 ">{productDetails.product_price}
                        CZK</span>
                    <span class="text-2xl md:text-3xl lg:text-4xl font-extrabold">{productDetails.sale_price} CZK</span>
                </div>
            {:else }
                <div class='text-2xl md:text-3xl lg:text-4xl font-extrabold mb-3'> {productDetails.product_price} CZK
                </div>
            {/if}


            <div class='flex flex-col md:flex-row mt-16 select-text'>

                <!--			Select version-->
                {#if productDetails.is_spiked}
                    <div class='flex justify-center md:justify-start dropdown dropdown-bottom'>
                        <label tabindex='0'
                               class='select-text flex flex-row items-center justify-between border w-full md:w-52 h-12 px-2 cursor-pointer'
                               on:click={closeDropDownVersion}>
                            {#if selectedVersion === 'VYBERTE VERZI'}
                                <div class='text-sm text-stone-600'>{selectedVersion}</div>
                            {:else}
                                {selectedVersion}
                            {/if}
                            <i class='bi bi-chevron-down'></i>
                        </label>
                        <ul tabindex='0'
                            class="dropdown-content menu p-2 background-dropdown w-full md:w-52 {toggleVersionDropDown === false ? 'hidden' : 'block'}">
                            <li class='bottom-border-dropdown'
                                on:click={() => {changeSelectedVersion(0); closeDropDownVersion()}}><a>SPIKED</a>
                            </li>
                            <li class='bottom-border-dropdown'
                                on:click={() => {changeSelectedVersion(1); closeDropDownVersion()}}><a>CLEAN</a>
                            </li>
                        </ul>
                    </div>
                {/if}

                <!--							Select size-->

                <div class='flex w-full justify-center md:justify-end dropdown dropdown-bottom mt-12 md:mt-0'>
                    <label tabindex='1'
                           class='select-text flex flex-row items-center justify-between border w-full md:w-52 h-12 px-2 cursor-pointer'
                           on:click={closeDropDownSize}>
                        {#if selectedSize === 'VYBERTE VELIKOST'}
                            <div class='text-sm text-stone-600'>{selectedSize}</div>
                        {:else}
                            {selectedSize}
                        {/if}
                        <i class='bi bi-chevron-down'></i>
                    </label>
                    <ul tabindex='1'
                        class="dropdown-content menu p-2 background-dropdown w-full md:w-52 {toggleSizeDropDown === false ? 'hidden' : 'block'}">
                        {#each availableSizes as size}
                            <li class='bottom-border-dropdown text-lg'
                                on:click={() => {changeSelectedSize(size); closeDropDownSize()}}>
                                <a>{size}</a></li>
                        {/each}
                    </ul>
                </div>
            </div>

            <!--			buttons-->
            <div class='flex justify-center items-center mt-8'>
                <label for="add-to-cart-modal"
                       class='w-full lg:w-full h-16 text-xl font-semibold buy-now-button btn rounded-none'
                       on:click={addItemToCart}>
                    PŘIDAT DO KOŠÍKU
                </label>
            </div>

            <!-- Put this part before </body> tag -->
            {#if addedToCart}
                <input type="checkbox" id="add-to-cart-modal" class="modal-toggle"/>
                <div class="modal modal-bottom sm:modal-middle">
                    <div class="modal-box">
                        <div class="flex font-bold text-base md:text-xl pb-10 align-middle">
                            <div class="flex flex-row w-full">
                                <i class="bi bi-check-circle-fill pr-2"></i> POLOŽKA BYLA
                                PŘIDÁNA DO KOŠÍKU
                            </div>
                            <label for="add-to-cart-modal" class="flex justify-end cursor-pointer">
                                <i class='bi bi-x-lg text-lg'></i>
                            </label>
                        </div>
                        <div class="flex flex-row">
                            <img class='w-1/3 product-image h-auto' src={productDetails.product_image}
                                 alt={productDetails.product_name}/>
                            <div class="flex flex-col  ml-6">
                                <span class="text-lg font-bold">Název: {productDetails.product_name}</span>
                                <span class="text-lg font-bold">Velikost: {selectedSize}</span>
                                <span class="text-lg font-bold">Verze: {selectedVersion}</span>
                            </div>
                        </div>
                        <div class="flex flex-row mt-8 gap-4 justify-center">
                            <a href="../cart" class="flex btn w-full white-button text-xl">DO KOŠÍKU</a>
                            <a href="../cart" class="flex whitespace-nowrap w-full to-cart-button btn text-xl">
                                CHECKOUT
                            </a>
                        </div>
                    </div>
                </div>
            {/if}

            <hr class='hr-separator-smaller my-6'>

            <!--			collapses-->
            <div class='collapse collapse-plus border my-3'>
                <input type='checkbox' class='peer'/>
                <div class='collapse-title text-xl font-medium'>
                    POPIS PRODUKTU
                </div>
                <div class='collapse-content'>
                    <span>POPIS: </span>
                    <p>Had repulsive dashwoods suspicion sincerity but advantage now him. Remark easily garret nor nay.
                        Civil
                        those mrs enjoy shy fat merry. You greatest jointure saw horrible. He private he on be imagine
                        suppose.
                        Fertile beloved evident through no service elderly is. Blind there if every no so at. Own
                        neglected you
                        preferred way sincerity delivered his attempted. To of message cottage windows do besides
                        against
                        uncivil.</p>
                </div>
            </div>

            <div class='collapse collapse-plus border my-3'>
                <input type='checkbox' class='peer'/>
                <div class='collapse-title text-xl font-medium'>
                    VELIKOSTI
                </div>
                <div class='collapse-content'>
                    <span>POPIS: </span>
                    <p>Had repulsive dashwoods suspicion sincerity but advantage now him. Remark easily garret nor nay.
                        Civil
                        those mrs enjoy shy fat merry. You greatest jointure saw horrible. He private he on be imagine
                        suppose.
                        Fertile beloved evident through no service elderly is. Blind there if every no so at. Own
                        neglected you
                        preferred way sincerity delivered his attempted. To of message cottage windows do besides
                        against
                        uncivil.</p>
                </div>
            </div>

            <div class='collapse collapse-plus border my-3'>
                <input type='checkbox' class='peer'/>
                <div class='collapse-title text-xl font-medium'>
                    MATERIAL
                </div>
                <div class='collapse-content'>
                    <span>POPIS: </span>
                    <p>Had repulsive dashwoods suspicion sincerity but advantage now him. Remark easily garret nor nay.
                        Civil
                        those mrs enjoy shy fat merry. You greatest jointure saw horrible. He private he on be imagine
                        suppose.
                        Fertile beloved evident through no service elderly is. Blind there if every no so at. Own
                        neglected you
                        preferred way sincerity delivered his attempted. To of message cottage windows do besides
                        against
                        uncivil.</p>
                </div>
            </div>

        </div>
    </div>
</div>

<style>

    .modal-box {
        border: 1px solid var(--text-color);
        border-radius: 0;
        background-color: var(--theme-color);
    }

    .select-text {
        @apply text-xl font-semibold;
    }

    .bi-check-circle-fill {
        color: var(--success-color)
    }

    .buy-now-button {
        color: var(--text-color);
        border: 2px solid var(--success-color);
        background-color: var(--success-color);
    }

    .white-button {
        @apply w-1/2 h-16 text-sm font-semibold bg-transparent rounded-none;
        color: var(--text-color);
        border: 2px solid var(--text-color);
    }

    .white-button:hover {
        @apply w-1/2 h-16 text-sm font-semibold bg-transparent rounded-none;
        color: var(--theme-color);
        background-color: var(--text-color);
        border: 2px solid var(--text-color);
    }

    .to-cart-button {
        @apply w-1/2 h-16 text-sm font-semibold bg-transparent rounded-none;
        color: var(--text-color);
        border: 2px solid var(--success-color);
        background-color: var(--success-color);
    }


    .buy-now-button:hover, .to-cart-button:hover {
        background-color: #01ad36;
        border-color: #01ad36;
    }

    .left-decor-border {
        border: 4px solid transparent;
        border-radius: 0.2rem;
        border-image: -moz-linear-gradient(180deg, rgba(136, 8, 181, 1) 24%, rgba(7, 7, 7, 1) 100%);
        border-image: -webkit-linear-gradient(180deg, rgba(136, 8, 181, 1) 24%, rgba(7, 7, 7, 1) 100%);
        border-image: linear-gradient(180deg, rgba(136, 8, 181, 1) 24%, rgba(7, 7, 7, 1) 100%);
        border-image-slice: 1;
    }
</style>