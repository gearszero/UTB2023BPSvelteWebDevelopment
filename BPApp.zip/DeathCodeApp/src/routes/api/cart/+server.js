// Posting a new add to cart on database
import {fail} from "@sveltejs/kit";
import "$lib/supabaseClient.js";
import {supabaseClient} from "$lib/supabaseClient.js";

export const POST = async ({params}) => {
    const session = await supabaseClient.auth.getSession()
    if (session !== null) {
        const {data, error: err} = await supabaseClient.from('user_cart').insert([{
            user_id: session.data.session.user.id,
            quantity: params.quantity,
            product_id: params.product_id,
            product_type: params.product_type,
            product_version: params.product_version,
            product_size: params.product_size,
            product_name: params.product_name,
            product_image: params.product_image,
        }])

        if (err) {
            return fail(500, {
                error: 'Server error: Please try again later'
            })
        }

        return new Response(JSON.stringify({message: "Success", data: data}), {status: 200})
    }
    else {
        return fail(401, {
            error: 'Unauthorized'
        })
    }
}

