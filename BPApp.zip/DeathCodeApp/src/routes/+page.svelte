<script>
    import Separator from '../components/separator.svelte';
    import {getCartLength, getCartItems, clearCart} from '../store/usersCartStore.js';
    import {POST} from '/src/routes/api/cart/+server.js';
    import {onMount} from "svelte";

    //exports
    export let data;

    let storeData = [];
    onMount(() => {
        storeData = getCartItems();
        if (data.session !== null) {
            putStoreData()
        }
    })

    function putStoreData() {
        if (data.session !== null) {
            if (getCartLength() > 0) {
                for (const item of storeData) {
                    console.log("item: ", item);
                    const postStore =
                        {
                            product_id: item.product_id,
                            product_type: item.product_type,
                            product_name: item.product_name,
                            product_image: item.product_image,
                            quantity: item.quantity,
                            version: item.version,
                            product_size: item.product_size
                        }
                    POST({params: postStore});
                }
                clearCart();
            }
        }
    }
</script>

<div class="flex flex-wrap justify-center items-center flex-col mt-10 w-full lg:max-2xl:mt-20">
    <div class='flex justify-center h-96 lg:h-screen w-3/4'>
        <div class='flex h-4/5 items-center z-10'>
            <div class='text-5xl text-style-header'>DEATHCODE</div>
        </div>
        <div
                class="flex absolute z-0 h-4/5 mt-24 svg-container-logo"
                style="background-image: url('src/tmpPics/LogoWithoutD.svg')"
        >
        </div>
    </div>

    <div class="flex w-full pl-14">
        <span class="sm:text-lg md:text-2xl lg:text-3xl 2xl:text-6xl font-extrabold text-color-purple">2023: </span>
        <span class="sm:text-lg md:text-2xl lg:text-3xl 2xl:text-6xl font-extrabold pl-4">NEW COLL.</span>
    </div>
</div>

<div class="my-12">
    <Separator/>
</div>

<div class="flex w-full justify-center">
    <div class="border rounded-none w-3/4 h-[42rem] bg-white"></div>
</div>

<div class="my-12">
    <Separator/>
</div>

<!--New products-->
<div class="main">
    <div class="flex w-full justify-center">
        <span class='text-3xl sm:text-6xl md:text-6xl lg:text-7xl xl:text-9xl font-extrabold products-text'> NEW </span>
        <span class='text-3xl sm:text-6xl md:text-6xl lg:text-7xl xl:text-9xl font-extrabold stroke-text font-extrabold ml-6'> PRODUCTS </span>
    </div>
    <div class='flex flex-col xl:flex-row w-full justify-center items-center mt-5 gap-8'>
        <div class='border rounded-none w-[24rem] h-[32rem] bg-white'></div>
        <div class='border rounded-none w-[24rem] h-[32rem] bg-white'></div>
        <div class='border rounded-none w-[24rem] h-[32rem] bg-white'></div>
    </div>

    <div class='flex flex-col justify-end items-end'>
        <div class='svg-container-stars' style="background-image: url('src/tmpPics/Stars.svg')"></div>
        <div class='svg-container-bar-code' style="background-image: url('src/tmpPics/BarCode.svg')"></div>
        <span class='font-bold text-2xl'>PWD</span>
    </div>
</div>

<style>
    .main {
        @apply mx-12 mt-20;
    }

    .tmp-border-picture {
        border: 1px solid;
        width: 95%;
        height: 900px;
        background-color: #b2b2b2;
    }

    @keyframes typewriter {
        from {
            width: 0;
        }
        to {
            width: 100%;
        }
    }

    @keyframes blinkTextCursor {
        from {
            border-right-color: hsl(0, 0%, 80%);
        }
        to {
            border-right-color: transparent;
        }
    }

    @media only screen and (max-width: 1023px) {

        .stroke-text {
            -webkit-text-stroke-width: 2px;
            -webkit-text-fill-color: var(--theme-color);
        }

        .svg-container-logo {
            width: 16.625rem;
            height: 15.125rem;
            opacity: 0;
            background-size: contain;
            background-repeat: no-repeat;
            animation: svgAppear 2s forwards;
            animation-delay: 2s;
        }

        .text-style-header {
            font-weight: 100;
            z-index: 10;
            border-right: 2px solid hsl(0, 0%, 80%);
            animation: typewriter 1.5s steps(18) normal, blinkTextCursor 0.75s infinite;
            white-space: nowrap;
            overflow: hidden;
        }
    }


    @media only screen and (min-width: 1024px) {

        .stroke-text {
            -webkit-text-stroke-width: 3px;
            -webkit-text-fill-color: var(--theme-color);
        }

        .svg-container-logo {
            width: 36.625rem;
            height: 35.125rem;
            opacity: 0;
            background-size: contain;
            background-repeat: no-repeat;
            animation: svgAppear 2s forwards;
            animation-delay: 2s;
        }

        .text-style-header {
            font-size: 9.375rem;
            font-weight: 100;
            z-index: 10;
            border-right: 4px solid hsl(0, 0%, 80%);
            animation: typewriter 1.5s steps(18) normal, blinkTextCursor 0.75s infinite;
            white-space: nowrap;
            overflow: hidden;
        }
    }

    @keyframes svgAppear {
        from {
            opacity: 0;
        }
        to {
            opacity: 0.5;
        }
    }

    .svg-container-bar-code {
        width: 20rem;
        height: 5rem;
        background-repeat: no-repeat;
        background-size: 20rem;
    }

    .svg-container-stars {
        width: 5rem;
        height: 5rem;
        background-repeat: no-repeat;
    }
</style>
