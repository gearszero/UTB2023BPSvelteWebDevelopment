import { supabaseClient } from '$lib/supabaseClient';
import { fail } from '@sveltejs/kit';
import { setSaleRatio } from '$lib/utils.js';

export async function load({params}) {
	console.log("params: " + JSON.stringify(params))

	const { data, error: err } = await supabaseClient.from(params.productPage).select()

	if (err) {
		return fail(500, {
			error: 'Server error: Please try again later'
		})
	}

	data.forEach((product) => {
		if (product.is_on_sale) {
			product.sale_price = setSaleRatio(product.product_price, product.sale_ratio)
		}
	});

	return {
		productsData: data,
	}
}