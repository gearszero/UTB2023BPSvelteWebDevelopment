<script lang="ts">
	import Separator from '../../components/separator.svelte';
	import ProductWidget from '../../components/productWidget.svelte';
	import { onMount } from 'svelte';
	import { page } from '$app/stores';

	//exports
	export let data;
	const productType = $page.params.productPage
	const productHeader = String(productType);

	let products = [];
	onMount(() => {
		products = data.productsData;
	});

</script>

<div class="w-full h-screen relative flex flex-col welcome-theme-color hidden xl:block">
	<div class="text-5xl sm:text-6xl md:text-7xl lg:text-9xl xl:text-[9rem] font-extrabold flex justify-center h-full items-center">{productHeader.toUpperCase()}</div>
</div>

<div class='mt-20 md:mt-44 xl:mt-0'>
	<Separator />
</div>

<div class='block xl:hidden mt-10'>
	<span class='text-start ml-4 text-4xl md:text-6xl lg:text-7xl font-bold mt-10 lg:mt-20 tracking-[0.6rem]'>{productHeader.toUpperCase()}</span>
</div>


<div class="flex flex-wrap justify-center items-center flex-col mt-10 w-full lg:mt-20" >
	<div class="grid grid-cols-2 md:grid-cols-2 xl:grid-cols-3">
		{#each data.productsData as product}
			<a href='../{product.product_id}t={product.product_type}'>
				<div class="flex flex-col justify-center items-center w-full">
					<ProductWidget product={product} />
				</div>
			</a>
		{/each}
		</div>
</div>

<style>
	.welcome-theme-color {
		background-color: var(--second-theme-color);
	}
</style>
