import { AuthApiError } from '@supabase/supabase-js';
import { fail, redirect } from '@sveltejs/kit';
import {getCartLength, getCartItems, clearCart} from "../../store/usersCartStore.js";
import {POST} from "../api/cart/+server.js";


export const actions = {
	login: async ({ request, locals }) => {
		const body = Object.fromEntries(await request.formData());

		const { data, error:err } = await locals.sb.auth.signInWithPassword({
			email: body.email,
			password: body.password
		});

		if (err) {
			if (err instanceof AuthApiError && err.status === 400) {
				return fail(400, {
					error: 'Invalid email or password'
				})
			}
			return fail(500, {
				error: 'Server error: Please try again later'
			})
		}
		console.log("cart length: " + getCartLength());

		if (getCartLength() > 0) {
			const tmpStoreData = getCartItems();
			for await (const item of tmpStoreData) {
				const postStore =
					{
						user_id: data.user.id,
						product_id: item.product_id,
						product_type: item.product_type,
						product_name: item.product_name,
						product_image: item.product_image,
						quantity: item.quantity,
						version: item.version,
						product_size: item.product_size
					}
					await POST({params: postStore});
			}
			clearCart();
		}

		throw redirect(303, '/')
	}
}