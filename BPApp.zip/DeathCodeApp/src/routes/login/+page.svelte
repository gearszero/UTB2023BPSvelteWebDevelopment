<script>

</script>

<div class='main'>
    <form action='?/login' method='POST' class='flex flex-col items-center justify-center'>
        <div class='font-extrabold text-4xl mb-5'>
            LOG IN
        </div>
        <input type='email' name='email' placeholder='EMAIL' class='input-field'>
        <input type='password' name='password' placeholder='PASSWORD' class='input-field'>
        <button class='big-form-button'>
            LOG IN
        </button>
        <a href='../signup' class="narrow-big-form-button flex justify-center items-center">
            SIGN UP
        </a>
    </form>
</div>

<style>
    .main {
        @apply flex justify-center items-center mt-64;
    }

    .input-field {
        @apply w-full h-12 pl-5 text-xl font-semibold my-5;
        background-color: var(--theme-color);
        border-bottom: 2px solid var(--text-color);
    }

    .input-field::placeholder {
        color: #545454;
    }

    .login-button:hover {
        background-color: var(--text-color);
        color: var(--theme-color);
    }

    .signup-button {
        color: var(--text-color);
        border: 2px solid var(--text-color);
    }

    .signup-button:hover {
        background-color: var(--text-color);
        color: var(--theme-color);
    }

</style>


