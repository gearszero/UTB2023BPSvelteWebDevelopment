<script>
	import CartProductCard from '../../components/cartProductCard.svelte';
	import { onMount } from 'svelte';
	import { usersCartStore } from '../../store/usersCartStore';

	export let data;

	let cartData = [];

    $: {
		cartData;
    }

	onMount(() => {
		if (data.session === null) {
			cartData = $usersCartStore;
		}
		else {
			cartData = data.cartData
		}
		console.log(data.cartData)
	});

</script>

<div class='main'>

	<!--	Top logo-->
	<div class='flex py-24 justify-center'>
		<div
			class='flex svg-container-logo static justify-center items-center'
			style="background-image: url('src/tmpPics/LogoWithoutD.svg')"
		>
			<div class='flex justify-center w-full text-4xl font-extrabold'>
				KOŠÍK
			</div>
		</div>
	</div>

	<div class='ml-24 text-2xl font-extrabold'>
		VAŠE POLOŽKY:
	</div>

	<div class='flex flex-row'>
		<div class='flex flex-col gap-y-8'>
			{#each cartData as item}
				<div class='flex w-full'>
				<CartProductCard product={item} maximumQuantity={data.maximumQuantity} isLocal={data.isLocal} />
				</div>
			{/each}
		</div>
	</div>

</div>

<style>
    .svg-container-logo {
        width: 12rem;
        height: 11rem;
        background-size: contain;
        background-repeat: no-repeat;
    }

</style>