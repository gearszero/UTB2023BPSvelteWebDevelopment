import {supabaseClient} from "$lib/supabaseClient.js";
import {fail} from "@sveltejs/kit";

export const load = async ({parent}) => {
    const {session} = await parent();
    if (session !== null) {
        const {
            data: dataOrder,
            error: err
        } = await supabaseClient.from('user_cart').select('* ').eq('user_id', session.user.id)

        if (err) {
            return fail(500, {
                error: 'Server error: Please try again later'
            })
        }
        console.log('dataOrder', dataOrder);

        return {
            cartData: dataOrder,
            maximumQuantity: 10,
            isLocal: false
        };
    } else {
        return {
            cartData: [],
            maximumQuantity: 10,
            isLocal: true
        };
    }
};