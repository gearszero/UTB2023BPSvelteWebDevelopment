import React, { useState } from "react";

function DomTest() {
    const [items, setItems] = useState([]);

    const addItem = () => {
        setItems([...items, `Item ${items.length + 1}`]);
    };

    return (
        <div className="App">
            <button onClick={addItem}>Přidat prvek</button>
            {items.map((item, index) => (
                <div key={index}>{item}</div>
            ))}
        </div>
    );
}

export default DomTest;