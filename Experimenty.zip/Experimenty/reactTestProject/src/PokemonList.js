import React, { useState, useEffect } from 'react';
import './App.css';

function PokemonList() {
    const [pokemon, setPokemon] = useState([]);

    useEffect(() => {
        fetch('https://pokeapi.co/api/v2/pokemon?limit=700')
            .then((response) => response.json())
            .then((data) => Promise.all(data.results.map(p => fetch(p.url).then(res => res.json()))))
            .then((pokemonData) => setPokemon(pokemonData))
            .catch((error) => console.error(error));
    }, []);

    return (
        <div className="App">
            <table>
                <tbody>
                {pokemon.map((p, index) => (
                    <tr key={index}>
                        <td><img src={p.sprites.front_default} alt={p.name} /></td>
                        <td>{p.name}</td>
                        <td>{p.height}</td>
                        <td>{p.weight}</td>
                    </tr>
                ))}
                </tbody>
            </table>
        </div>
    );
}

export default PokemonList;
