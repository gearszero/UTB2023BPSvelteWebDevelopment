import React, { useState, useEffect } from 'react';

function PokemonList() {
    const [pokemon, setPokemon] = useState([]);

    useEffect(() => {
        const fetchData = async () => {
            try {
                const response = await fetch('https://pokeapi.co/api/v2/pokemon?limit=1000');
                const data = await response.json();
                const pokemonData = await Promise.all(data.results.map(async p => {
                    const res = await fetch(p.url);
                    return res.json();
                }));
                setPokemon(pokemonData);
            } catch (error) {
                console.error(error);
            }
        };
        fetchData();
    }, []);


    const renamePokemon = () => {
        const start = performance.now();
        const newPokemon = pokemon.map(p => ({ ...p, name: 'Pokemon' }));
        setPokemon(newPokemon);
        const end = performance.now();
        console.log('Operation time: ' + (end - start) + ' ms');
    };

    const addPokemon = () => {
        const start = performance.now();
        const newPokemon = [...pokemon, ...pokemon.slice(0, 1000)];
        setPokemon(newPokemon);
        const end = performance.now();
        console.log('Operation time: ' + (end - start) + ' ms');
    };

    const removePokemon = () => {
        const start = performance.now();
        const newPokemon = pokemon.slice(0, pokemon.length - 1000);
        setPokemon(newPokemon);
        const end = performance.now();
        console.log('Operation time: ' + (end - start) + ' ms');
    };

    return (
        <div className="App">
            <button onClick={renamePokemon}>Rename Pokemon</button>
            <button onClick={addPokemon}>Add 1000 Pokemon</button>
            <button onClick={removePokemon}>Remove 1000 Pokemon</button>
            <table>
                <tbody>
                {pokemon.map((p, index) => (
                    <tr key={index}>
                        <td>{p.name}</td>
                    </tr>
                ))}
                </tbody>
            </table>
        </div>
    );
}

export default PokemonList;
