import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import PokemonList from './PokemonList';
import DomTest from './DomTest';
import StateChange from "./StateChange";
import ListOperations from "./ListOperations";

function App() {
    return (
        <Router>
            <div className="App">
                <Routes>
                    <Route path="/domtest" element={<DomTest />} />
                    <Route path="/statechange" element={<StateChange />} />
                    <Route path="/listop" element={<ListOperations />} />
                    <Route path="/" element={<PokemonList />} />
                </Routes>
            </div>
        </Router>
    );
}

export default App;
